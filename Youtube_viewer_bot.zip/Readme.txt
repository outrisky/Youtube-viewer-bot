Welcome to the best youtube viewer bot !!!

How to run it :

1- Run Ytbot as administrator 
2- Add your stream/video id there example : "https://www.youtube.com/watch?v=123456789"  123456789 is the id
3- Put threads between 500 and 1000
4- Download free proxies ( proxyscrape.com )
5- Select the proxy file
6- Enjoy the viewers 